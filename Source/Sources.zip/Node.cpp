#include "Node.h"

using namespace std;
using namespace cv;

Node::Node(void)
{
}

Node::Node(cv::Point ptin)
{
	pt = ptin;
}

Node::~Node(void)
{
}
